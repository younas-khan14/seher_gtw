// Hive adapter removed. File can be deleted if not used elsewhere.
